require_relative 'board'
require_relative 'human_player'
require_relative 'computer_player'

class Game
end
