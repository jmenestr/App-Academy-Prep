class Dictionary
  # TODO: your code goes here!
end
