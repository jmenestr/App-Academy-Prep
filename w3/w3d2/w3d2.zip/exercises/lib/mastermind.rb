class Code
  attr_reader :pegs
end

class Game
  attr_reader :secret_code
end
