class HumanPlayer
end
